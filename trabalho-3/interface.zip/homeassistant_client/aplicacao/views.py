# -*- coding:utf-8 -*-
from django.shortcuts import render
"""from django.shortcuts import render_to_response"""
"""from homeassistant_client.aplicacao.forms import FormContato"""

# Create your views here.

from aplicacao.models import Nome

def index(request):
    """View function for home page of site."""

    # Generate counts of some of the main objects
    name = Nome.objects.all().count()

    context = {
    'name': name,
}

    # Render the HTML template index.html with the data in the context variable
    return render(request, 'index.html', context=context)