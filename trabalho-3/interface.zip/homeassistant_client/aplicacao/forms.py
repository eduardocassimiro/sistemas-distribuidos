# -*- coding:utf-8 -*-
from django import forms
   
class FormContato(forms.Form):
    nome = forms.CharField()
    estado = forms.BooleanField()
    mensagem = forms.CharField(widget=forms.Textarea())