from django.db import models

# Create your models here.

class Nome(models.Model):
    """representa o nome do dispositivo"""
    name = models.CharField(max_length=200, help_text='Escreva o nome do dispositivo')

    def __str__(self):
        """String for representing the Model object."""
        return self.name
