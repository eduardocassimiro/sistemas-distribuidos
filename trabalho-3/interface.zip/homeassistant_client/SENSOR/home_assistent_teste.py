import pika, sys, os
import smart_obj_pb2 as SmartObject

# Instânciando um 
sensor = SmartObject.SmartObject()

# Variável teste para status da lampada
status_lamp = 'OFF'

def main():
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.exchange_declare(exchange='logs', exchange_type='fanout')

    result = channel.queue_declare(queue='', exclusive=True)
    queue_name = result.method.queue

    channel.queue_bind(exchange='logs', queue=queue_name)


    # --- Rotina da fila
    def callback(ch, method, properties, body):
        # --- Teste sensor
        sensor.ParseFromString(body)
        #print(sensor.data)

        # --- Teste atuador
        cmd = input('Digite 1 para saber a última leitura e 2 para mudar o satatus da lampada:')
        if cmd == '1':
            print(sensor.data)
        if cmd == '2':
            status_lamp = input('-- Digite ON para ligar e OFF para desligadar:' )

        

    print(' [*] Waiting for logs. To exit press CTRL+C')
    channel.basic_consume(
        queue=queue_name, on_message_callback=callback, auto_ack=True)

    channel.start_consuming()



if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Interrupted')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)

#protoc -I=. --python_out=. ./todolist.proto