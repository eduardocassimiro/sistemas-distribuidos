import pika
import sys
from random import randrange,random
import time
import json
import smart_obj_pb2 as SmartObject

# --- Definição da classe do atuador

class Actuator(object):
    def __init__(self, id, name, type):
        self.id = id
        self.name = name
        self.type = type
        self.status = 'OFF'

    def turnON():
        if(self.status == 'OFF'):
            self.status = 'ON'
            print('LAMP TURNED ON')

    def turnOFF():
        if(self.status == 'ON'):
            self.status = 'OFF'
            print('LAMP TURNED ON')


lamp = Actuator(1, 'LAMP', 'ACTUATOR')

# --- Definição da classe serializável do atuator

slamp = SmartObject.SmartObject()
slamp.id = lamp.id
slamp.name = lamp.name
slamp.type = SmartObject.TypeObject.Value(lamp.type)


# --- Conexão RabbitMQ

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

channel.exchange_declare(exchange='logs', exchange_type='fanout')

#device_info = {'id': 1,'name': 'TEMP', 'type': 'sensor'}
#message = {'info': device_info,'data':0}

# --- Enviando os dados

while(True):
    slamp.data = str(randrange(22,24) + round(random(),2))
    message = slamp.SerializeToString(slamp)
    channel.basic_publish(exchange='logs', routing_key='', body=message)
    time.sleep(3)
#print(" [x] Sent %r" % message)
connection.close()
